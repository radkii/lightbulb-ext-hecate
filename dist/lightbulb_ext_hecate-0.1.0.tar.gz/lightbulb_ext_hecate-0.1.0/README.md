# lightbulb-ext-hecate
File driven wrappers around lightbulb extensions and plugins.
